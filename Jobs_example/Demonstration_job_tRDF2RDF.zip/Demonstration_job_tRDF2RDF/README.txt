1 - Make sure to have the tRDF2RDF component in your $TALEND_HOME/plugins/org.talend.designer.components.localprovider_$TALEND_VERSION/components
2 - Import the job in Talend
3 - Run the Job
