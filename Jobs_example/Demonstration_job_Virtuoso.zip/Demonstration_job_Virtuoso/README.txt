1 - Make sure to have all Virtuoso components in your $TALEND_HOME/plugins/org.talend.designer.components.localprovider_$TALEND_VERSION/components
2 - Import the job in Talend
3 - Run the Job
