1 - Make sure to have all Jena components in your $TALEND_HOME/plugins/org.talend.designer.components.localprovider_5.4.1.r111943/components/ext
2 - Import the job in Talend
3 - Change the path of the tJenaReadFile_1 component to point out the data_sample.nt file
4 - Run the Job
