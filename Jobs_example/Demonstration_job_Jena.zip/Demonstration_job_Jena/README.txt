1 - Make sure to have all Jena components in your $TALEND_HOME/plugins/org.talend.designer.components.localprovider_$TALEND_VERSION/components
2 - Import the job in Talend
3 - Change the path of the tJenaReadFile_1 component to lead to the data_sample.nt file
4 - Run the Job
